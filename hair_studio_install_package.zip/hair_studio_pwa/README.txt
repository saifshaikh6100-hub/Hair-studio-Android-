HAIR STUDIO – PWA INSTALL PACKAGE

Files:
- index.html: app
- manifest.webmanifest: install metadata
- sw.js: offline app shell cache
- icon.svg: app icon

IMPORTANT:
This package must be hosted on an HTTPS website before customers can install it.
Android: open the HTTPS link in Chrome and tap Install App (or browser menu > Install app).
iPhone: open the HTTPS link in Safari > Share > Add to Home Screen.

The current prototype still stores bookings only in each device's browser local storage.
It does NOT sync bookings across customer phones and the owner dashboard yet.
A shared online database and owner login are needed for live salon use.
